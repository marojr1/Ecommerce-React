import { useEffect, useState } from "react";
import ListaProdutos from "./componentes/ListaProdutos";
import "./App.css";

function App() {
  const [produtos, setProdutos] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState("");

  useEffect(() => {
    fetch("https://fakestoreapi.com/products?limit=12")
      .then((resposta) => {
        if (!resposta.ok) {
          throw new Error("Erro ao buscar produtos");
        }

        return resposta.json();
      })
      .then((dados) => {
        setProdutos(dados);
        setCarregando(false);
      })
      .catch((erro) => {
        setErro(erro.message);
        setCarregando(false);
      });
  }, []);

  if (carregando) {
    return <h2>Carregando...</h2>;
  }

  if (erro) {
    return <h2>{erro}</h2>;
  }

  return (
    <div className="app">
      <h1>E-Commerce Web 2</h1>

      <ListaProdutos produtos={produtos} />
    </div>
  );
}

export default App;
function CardProduto({ produto }) {
  return (
    <div className="card">
      <img
        src={produto.image}
        alt={produto.title}
        className="imagem-produto"
      />

      <h2>{produto.title}</h2>

      <p className="categoria">
        Categoria: {produto.category}
      </p>

      <p className="preco">
        R$ {produto.price}
      </p>
    </div>
  );
}

export default CardProduto;
import CardProduto from "./CardProduto";

function ListaProdutos({ produtos }) {
  return (
    <div>
      <h1 style={{ textAlign: "center", color: "black" }}>Lista de Produtos</h1>
      <div className="grade-produtos">
        {produtos.map((produto) => (
          <CardProduto
            key={produto.id}
            produto={produto}
          />
        ))}
      </div>
    </div>
  );
}

export default ListaProdutos;